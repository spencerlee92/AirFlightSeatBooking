/**
 * This class is the subclass of seatmap. It is used to initialize a seat map
 * according to the air bus plane seat policy.
 * 
 * @author TAO LI
 *
 */
public class BoeingSeatMap extends SeatMap {

	public BoeingSeatMap() {
		this.setRow(10);
		this.setColumn(7);
		this.setRowOfFirstClass(4);
		this.setSeat(10, 7);
		this.initialiseSeatMap();

	}

	/**
	 * This method is used to initialize each seat with individual value. And
	 * the seat type is initialized according to the boeing air plane. The first
	 * class and economy seat should be different symbols like Aisle seat. If
	 * the seat is in the row of first class, it should be symbol like uppercase
	 * A for aisle seat type. If the seat is in the rest of row, it should be
	 * lowercase a for aisle seat type.
	 * 
	 * 
	 */

	@Override
	void initialiseSeatMap() {
		for (int i = 0; i < this.getRow(); i++) {
			for (int j = 0; j < this.getColumn(); j++) {
				this.seat[i][j] = new Seat();
				if (j == 0 || j == this.getColumn() - 1) {
					this.seat[i][j].setSeatType(SEATTYPE.WINDOW);
					this.seat[i][j].setReserved(false);
					this.seat[i][j].setSeatPosition(i + 1, (char) (j + 65));
					if (i >= this.getRowOfFirstClass())
						this.seat[i][j].setFirstClass(false);
					else
						this.seat[i][j].setFirstClass(true);
				} else if (j == this.getColumn() / 2) {
					this.seat[i][j].setSeatType(SEATTYPE.MIDDLE);
					this.seat[i][j].setReserved(false);
					this.seat[i][j].setSeatPosition(i + 1, (char) (j + 65));
					if (i >= this.getRowOfFirstClass())
						this.seat[i][j].setFirstClass(false);
					else
						this.seat[i][j].setFirstClass(true);
				} else {
					this.seat[i][j].setSeatType(SEATTYPE.AISLE);
					this.seat[i][j].setReserved(false);
					this.seat[i][j].setSeatPosition(i + 1, (char) (j + 65));
					if (i >= this.getRowOfFirstClass())
						this.seat[i][j].setFirstClass(false);
					else
						this.seat[i][j].setFirstClass(true);
				}
			}
		}

	}

}
