/**
 * This is an abstract class is used by SimpleJet and RynoAir. It contains two
 * abstract method can be used to reserve seat in economy or economy.
 * 
 * @author TAO LI
 *
 */
public abstract class Airline {
	abstract Seat reserveFirstClass(Flight f, SEATTYPE sT);

	abstract Seat reserveEconomy(Flight f, SEATTYPE sT);

	private String airName;

	public Airline() {
		this.setAirName("UNKNOWN");
	}

	public Airline(String airName) {
		this.setAirName(airName);
	}

	public String toString() {
		return "This is " + this.getAirName() + " airline.";
	}

	public String getAirName() {
		return airName;
	}

	public void setAirName(String airName) {
		this.airName = airName;
	}

}
