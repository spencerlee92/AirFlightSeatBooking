/**
 * This class stores some instance variables about the flight information like
 * the flight number etc.
 * 
 * @author TAO LI
 */

public class Flight {
	private String startCity;
	private String destCity;
	private String departTime;
	private String flightNum;
	private SeatMap seatMap;

	public Flight(String startCity, String destCity, String departTime, String flightNum, SeatMap seatMap) {
		this.setStartCity(startCity);
		this.setDestCity(destCity);
		this.setDepartTime(departTime);
		this.setFlightNum(flightNum);
		this.setSeatMap(seatMap);
	}

	public Flight() {
		this.setStartCity("UNKNOWN");
		this.setDestCity("UNKNOWN");
		this.setDepartTime("UNKNOWN");
		this.setFlightNum("UNKNOWN");
		this.setSeatMap(seatMap);
	}

	/**
	 * This toString method is used to give a text representation of flight for
	 * user to choose
	 * 
	 * @return a flight string representation
	 */

	public String toString() {
		return "-Start city: " + this.getStartCity() + " -Destination City: " + this.getDestCity()
				+ " -Departure Time: " + this.getDepartTime();
	}

	public String getStartCity() {
		return startCity;
	}

	public void setStartCity(String startCity) {
		this.startCity = startCity;
	}

	public String getDestCity() {
		return destCity;
	}

	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}

	public String getDepartTime() {
		return departTime;
	}

	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}

	public String getFlightNum() {
		return flightNum;
	}

	public void setFlightNum(String flightNum) {
		this.flightNum = flightNum;
	}

	public SeatMap getSeatMap() {
		return seatMap;
	}

	public void setSeatMap(SeatMap seatMap) {
		this.seatMap = seatMap;
	}

}
