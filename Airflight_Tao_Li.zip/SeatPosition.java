/**
 * This class is used to store the instance variable of flight seat map's row
 * and column And also it contain a toString method to be used in the Seat
 * class's method seat() etc to represent the seat position such as '1A, 2C'
 * etc.
 * 
 * @author TAO LI
 *
 */
public class SeatPosition {
	private int row;
	private char column;

	public SeatPosition(int row, char column) {
		this.setRow(row);
		this.setColumn(column);
	}

	public SeatPosition() {
		this.setRow(1);
		this.setColumn('A');
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public char getColumn() {
		return column;
	}

	public void setColumn(char column) {
		this.column = column;
	}

	public String toString() {
		return "" + this.getRow() + this.getColumn();
	}

}
