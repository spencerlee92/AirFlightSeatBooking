/**
 * This class is used by SeatMap class. It contains instance variables used to
 * define is the seat reserved or not, is the seat in first class or not, what
 * kind of seat user want (defined in enurm type SEATTYPE) and contain the seat
 * position.
 * 
 * @author TAO LI
 *
 */
public class Seat {
	private boolean isReserved;
	private boolean isFirstClass;
	private SEATTYPE seatType;
	private SeatPosition seatPosition;

	public Seat() {
		this.setReserved(false);
		this.setFirstClass(false);
		this.setSeatType(SEATTYPE.AISLE);
		this.setSeatPosition(1, 'A');
	}

	public Seat(boolean isR, boolean isF, SEATTYPE sT, int row, char column) {
		this.setReserved(isR);
		this.setFirstClass(isF);
		this.setSeatType(sT);
		this.setSeatPosition(row, column);
	}

	/**
	 * This toString method would check all the boolean instance variable and
	 * its matching seat type in the enurm class. Then it will give a more
	 * graphic kind of symbol to represent all these variable value so that it
	 * could be used in the SeatMap to show the status of the seat
	 *
	 * @return String symbol representation of the seat
	 */

	public String toString() {
		String s = "";
		if (this.getSeatType() == SEATTYPE.AISLE) {
			if (isFirstClass) {
				if (isReserved) {
					s += " A[X] ";
				} else {
					s += " A[ ] ";
				}
			} else {
				if (isReserved) {
					s += " a[X] ";
				} else {
					s += " a[ ] ";
				}
			}
		} else if (this.getSeatType() == SEATTYPE.MIDDLE) {
			if (isFirstClass) {
				if (isReserved) {
					s += " M[X] ";
				} else {
					s += " M[ ] ";
				}
			} else {
				if (isReserved) {
					s += " m[X] ";
				} else {
					s += " m[ ] ";
				}
			}

		} else if (this.getSeatType() == SEATTYPE.WINDOW) {
			if (isFirstClass) {
				if (isReserved) {
					s += " W[X] ";
				} else {
					s += " W[ ] ";
				}
			} else {
				if (isReserved) {
					s += " w[X] ";
				} else {
					s += " w[ ] ";
				}
			}

		}
		return s;
	}

	/**
	 * This method is used to give a text representation of the seat status.
	 * 
	 * @return String text representation of the seat status
	 */

	public String seat() {
		return this.firstOrEconomy() + " " + this.getSeatType() + " seat at: " + this.getSeatPosition()
				+ this.reservedOrNot();
	}

	public boolean isReserved() {
		return isReserved;
	}

	/**
	 * This method is used by seat() method above to give the elegant text
	 * represent of the status instead of just returning true and false on the
	 * console
	 * 
	 * @return the elegant status of reserving status
	 */

	public String reservedOrNot() {
		if (isReserved) {
			return " is reserved.";
		} else {
			return " is not reserved";
		}
	}

	public void setReserved(boolean isReserved) {
		this.isReserved = isReserved;
	}

	public boolean isFirstClass() {
		return isFirstClass;
	}

	/**
	 * This method is used by seat() method to give the elegant text represent
	 * of the status instead of just returning true and false on the console
	 * 
	 * @return the elegant representation of which class the seat belongs to
	 */

	public String firstOrEconomy() {
		if (this.isFirstClass) {
			return "First class";
		} else {
			return "Economy class";
		}

	}

	public void setFirstClass(boolean isFirstClass) {
		this.isFirstClass = isFirstClass;
	}

	public SEATTYPE getSeatType() {
		return seatType;
	}

	public void setSeatType(SEATTYPE seatType) {
		this.seatType = seatType;
	}

	public SeatPosition getSeatPosition() {
		return seatPosition;
	}

	/**
	 * This method is used to set seat position. It takes two parameter to
	 * invoke the SeatPosition constructor
	 * 
	 * @param row
	 * @param column
	 */

	public void setSeatPosition(int row, char column) {
		this.seatPosition = new SeatPosition(row, column);
	}
}
