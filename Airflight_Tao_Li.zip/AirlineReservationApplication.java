
/**
 * This class is used to interact with all the other class. And it contians several methods 
 * from these class. And these methods is grouped to be several new methods. A flight array is
 * initialized in this class as well.
 * 
 * @author TAO LI
 */

import java.util.Scanner;

public class AirlineReservationApplication {
	static Scanner keyboard = new Scanner(System.in);
	public Flight[] flight;

	/**
	 * This welcome method is used to print a welcome banner and invoke the
	 * other method in the class.
	 */

	public void welcome() {
		System.out.println("Welcome to use this airline reservation application.");

		bookPlane(inputFlightAndDisplaySeat(numOfFlight()));
	}

	/**
	 * This method is used to ask user how many plane they want to input. And
	 * according to the number inputed by the user to decide the flight array's
	 * size.
	 * 
	 * @return a flight array
	 */

	public Flight[] numOfFlight() {
		System.out.println("How many flights info do you want to input?");
		int num = keyboard.nextInt();
		this.flight = new Flight[num];
		return flight;
	}

	/**
	 * This method is used to store the flight information data in the flight
	 * array. And it also ask user to choose what kind of air plane it is(boeing
	 * or air bus). Then it would initialize a seat map according to the input.
	 * After that it would query users if they want to input information for
	 * another plane or not
	 * 
	 * @param flight
	 *            array
	 * @return flight array contain a seat map
	 */

	public Flight[] inputFlightAndDisplaySeat(Flight[] flight) {
		boolean again = true;
		int i = 0;
		int j = flight.length;
		keyboard.nextLine();
		while (again) {
			System.out.println("Please input the detail about the flight: ");

			System.out.println("Enter start city: ");
			String startCity = keyboard.nextLine();

			System.out.println("Enter destination city: ");
			String destCity = keyboard.nextLine();

			System.out.println("Enter depart time: ");
			String departTime = keyboard.nextLine();

			System.out.println("Enter flight number: ");
			String flightNum = keyboard.nextLine();
			boolean again2 = true;
			while (again2) {
				System.out.println(
						"Please choose what kind of airplane it is(Please enter the number below): \n -1.Boeing\n -2.AirBus");
				int choice = keyboard.nextInt();
				if (choice == 1) {
					flight[i] = setBoeingFlight(startCity, destCity, departTime, flightNum);

					again2 = false;
				} else if (choice == 2) {
					flight[i] = setAirBus(startCity, destCity, departTime, flightNum);

					again2 = false;
				} else {
					System.out.println("You need to choose the number between 1 and 2.");
				}
			}
			if (j - 1 > i) {
				System.out.println("\nDo you want to enter another flight info(Yes/No)?");
				keyboard.nextLine();
				String info = keyboard.nextLine();
				if (info.equalsIgnoreCase("yes")) {
					i++;
				} else {
					again = false;
				}
			} else {
				again = false;
			}
		}
		return flight;
	}

	/**
	 * This method is used to reserve an airplane seat. It contains four choices
	 * for user to choose. The first choice(choice2) is used to ask user to
	 * choose a flight they want to book. The second choice(choice3) query user
	 * to choose a airplane company for this flight. The third choice(choice4)
	 * is to decide what kind of class they want to book, first or economy. The
	 * last choice(choice5) asks user to decide a seat type.After that it would
	 * according to the information just inputed to reserve a seat and would
	 * display a graphic seat map on the console with the seat booked with an
	 * uppercase X in the square bracket(ie A[X]). And this would ask user if
	 * they want to reserve another seat or not.
	 * 
	 * @param flight
	 */
	public void bookPlane(Flight[] flight) {
		boolean book = true;
		while (book) {
			System.out.println("\nPlease choice the flight you want to book(Please enter the number below): ");
			for (int j = 0; j < flight.length; j++) {
				if (flight[j] != null) {
					System.out.println((j + 1) + ". " + flight[j]);
				} else {
					System.out.println((j + 1)
							+ ". --------------------airline have not come out yet please be patient------------------\n-----------IMPORTANT:Please choose the existing airline , thanks-----------------");
				}
			}

			int choice2 = keyboard.nextInt();
			System.out.println("****************************************************************************");
			System.out.println("The airplane flight you choose is Flight Number" + flight[choice2 - 1].getFlightNum());
			System.out.println("Here is the plane seat: ");
			System.out.println(flight[choice2 - 1].getSeatMap());

			System.out.println(
					"There are two airpline companys available now.\nThe first is SimpleJet. When the seat types you want to choose are all reserved in first class, then the application\n "
							+ "will find and reserve any seat in the first class.If there are no seats available in\n first class then it will find and reserve a middle or window seat in economy class, also reserving one of the neighboring seats (for extra passenger room)\n"
							+ "If there are no seats matching any of these criteria then a reservation cannot be made.");
			System.out.println(
					"In the economy class of SimpleJet, if no such economy seat with matching type exists, then reserve and find any seat in the economy class.\nIf there are no seats matching any of these criteria then a reservation cannot be made. ");
			System.out.println(
					"The second is RynoAir. When the seat types you want to choose are all reserved in first class, then the application\nwill find and reserve any seat in the first class. If there is no seat available in the first class then find \nand reserve a middle seat in the economy, also reserving both the left side and right side neighbouring seats.\nIf there are no seats matching any of these criteria then a reservation cannot be made. ");
			System.out.println(
					"In the economy class of RynoAir, if no such economy seat with matching type exists, then reserve and find any seat in the economy class.\nIf there are no seats matching any of these criteria then a reservation cannot be made. ");

			System.out.println("\nPlease choose the airplane company for this plane:\n1.Simplet\n2.RynoAir");
			int choice3 = keyboard.nextInt();

			System.out.println("\nPlease choose the class you want to book:\n1.First Class\n2.Economy Class");
			int choice4 = keyboard.nextInt();

			System.out.println("\nPlease choose what type of seat do you want:\n1.Aisle\n2.Middle\n3.Window");
			int choice5 = keyboard.nextInt();
			System.out.println("****************************************************************************");

			Seat s = new Seat();
			if (choice3 == 1) {
				Airline air1 = new SimpleJet();
				if (choice4 == 1) {
					if (choice5 == 1) {
						s = air1.reserveFirstClass(flight[choice2 - 1], SEATTYPE.AISLE);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.AISLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. ");
							book = isBookAgain(book);
						}
					} else if (choice5 == 2) {
						s = air1.reserveFirstClass(flight[choice2 - 1], SEATTYPE.MIDDLE);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.MIDDLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 3) {
						s = air1.reserveFirstClass(flight[choice2 - 1], SEATTYPE.WINDOW);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.WINDOW);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					}

				} else if (choice4 == 2) {
					if (choice5 == 1) {
						s = air1.reserveEconomy(flight[choice2 - 1], SEATTYPE.AISLE);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.AISLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 2) {
						s = air1.reserveEconomy(flight[choice2 - 1], SEATTYPE.MIDDLE);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.MIDDLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 3) {
						s = air1.reserveEconomy(flight[choice2 - 1], SEATTYPE.WINDOW);
						if (s != null) {
							System.out.println("The SimpleJet company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.WINDOW);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					}
				}
			} else if (choice3 == 2) {
				Airline air2 = new RynoAir();
				if (choice4 == 1) {
					if (choice5 == 1) {
						s = air2.reserveFirstClass(flight[choice2 - 1], SEATTYPE.AISLE);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.AISLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 2) {
						s = air2.reserveFirstClass(flight[choice2 - 1], SEATTYPE.MIDDLE);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.MIDDLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 3) {
						s = air2.reserveFirstClass(flight[choice2 - 1], SEATTYPE.WINDOW);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.WINDOW);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					}

				} else if (choice4 == 2) {
					if (choice5 == 1) {
						s = air2.reserveEconomy(flight[choice2 - 1], SEATTYPE.AISLE);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.AISLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 2) {
						s = air2.reserveEconomy(flight[choice2 - 1], SEATTYPE.MIDDLE);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.MIDDLE);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					} else if (choice5 == 3) {
						s = air2.reserveEconomy(flight[choice2 - 1], SEATTYPE.WINDOW);
						if (s != null) {
							System.out.println("The RynoAir company's plane you booked is Flight"
									+ flight[choice2 - 1].getFlightNum() + " and the seat you booked is "
									+ SEATTYPE.WINDOW);
							System.out.println(s.seat());
							System.out.println(flight[choice2 - 1].getSeatMap());
							book = isBookAgain(book);
						} else {
							System.out.println("There is no seat available. Please book again");
							book = isBookAgain(book);
						}
					}
				}
			}
		}
	}

	/**
	 * This method is used to ask the user if they want to book another ticket
	 * or not. And the return boolean type will be used in the above method's
	 * while loop.
	 * 
	 * @param boolean
	 *            type
	 * @return decided boolean
	 */
	public boolean isBookAgain(boolean book) {
		keyboard.nextLine();
		System.out.println("Do you want to book another ticket?(yes/no)");
		String choice6 = keyboard.nextLine();
		if (choice6.equalsIgnoreCase("yes"))
			return true;
		else
			return false;
	}

	/**
	 * This method is used to link a boeing seat map with a flight.
	 * 
	 * @param startCity
	 * @param destCity
	 * @param departTime
	 * @param flightNum
	 * @return a flight linked with a boeing seat map
	 */

	public Flight setBoeingFlight(String startCity, String destCity, String departTime, String flightNum) {
		SeatMap s1 = new BoeingSeatMap();
		Flight f1 = new Flight(startCity, destCity, departTime, flightNum, s1);
		System.out.println(f1 + " -Boeing Flight");
		return f1;
	}

	/**
	 * This method is used to link a air bus seat map with a flight.
	 * 
	 * @param startCity
	 * @param destCity
	 * @param departTime
	 * @param flightNum
	 * @return a flight linked with a air bus seat map
	 */

	public Flight setAirBus(String startCity, String destCity, String departTime, String flightNum) {
		SeatMap s2 = new AirBusSeatMap();
		Flight f2 = new Flight(startCity, destCity, departTime, flightNum, s2);
		System.out.println(f2 + " -Air Bus Flight");
		return f2;
	}

	/**
	 * This method would output an elegant goobye banner
	 */

	public void goodbye() {
		System.out.println("****************************************************************************");
		System.out.println("Thank you for using airline reservation application! Have a nice trip! Ciao!");
	}

}
