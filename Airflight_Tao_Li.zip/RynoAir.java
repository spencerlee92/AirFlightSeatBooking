/**
 * This class extends the airline class and it extends the method used to
 * reserve economy and first class seat.
 * 
 * @author TAO LI
 *
 */

public class RynoAir extends Airline {
	public RynoAir() {
		this.setAirName("RynoAir");
	}

	/**
	 * This method is used to reserve a seat in the first class. It would check
	 * if there is an available seat with the matching request or not. If there
	 * is, then return that seat. If not, then it would find any available seat
	 * in the first class. If still not, then it would query middle seat in the
	 * economy. After that it would check if its right and left side is
	 * available or not. If there is , then it would also book these seats. If
	 * not, then return null. It also contains some method use ascii number and
	 * type cast to convert the column between integer and char.
	 *
	 * @param a
	 *            requested flight and seat type
	 * @return a seat in the first class
	 */

	@Override
	Seat reserveFirstClass(Flight f, SEATTYPE sT) {
		Seat st1 = new Seat();
		st1 = f.getSeatMap().queryAvailableFirstSeat(sT);

		if (st1 != null) {
			st1.setReserved(true);
			return st1;
		}

		else {
			for (int i = 1; i < f.getSeatMap().getRowOfFirstClass(); i++) {
				for (int j = 0; j < f.getSeatMap().getColumn(); j++) {
					if (f.getSeatMap().getSeat(i, (char) (j + 65)).isReserved() == false) {
						f.getSeatMap().getSeat(i, (char) (j + 65)).setReserved(true);
						st1 = f.getSeatMap().getSeat(i, (char) (j + 65));
						return st1;
					}
				}
			}
		}

		Seat st2 = new Seat();
		st2 = f.getSeatMap().queryAvailableEconomySeat(SEATTYPE.MIDDLE);
		if (st2 != null && f.getSeatMap().getLeft(st2).isReserved() != true
				&& f.getSeatMap().getRight(st2).isReserved() != true) {
			st2.setReserved(true);
			f.getSeatMap().getLeft(st2).setReserved(true);
			f.getSeatMap().getRight(st2).setReserved(true);
			return st2;
		} else {
			return null;
		}
	}

	/**
	 * This method is used to reserve a seat in the economy class. It would
	 * check if there is an available seat with the matching request or not. If
	 * there is, then return that seat. If not, then it would find any available
	 * seat in the economy. It also contains some method use ascii number and
	 * type cast to convert the column between integer and char.
	 *
	 * @param a
	 *            requested flight and seat type
	 * @return a seat in the economy class
	 */

	@Override
	Seat reserveEconomy(Flight f, SEATTYPE sT) {

		Seat st1 = new Seat();
		st1 = f.getSeatMap().queryAvailableEconomySeat(sT);
		if (st1 != null) {
			st1.setReserved(true);
			return st1;
		} else {
			for (int i = f.getSeatMap().getRowOfFirstClass(); i < f.getSeatMap().getLastRow(); i++) {
				for (int j = 0; j < f.getSeatMap().getColumn(); j++) {
					if (f.getSeatMap().getSeat(i, (char) (j + 65)).isReserved() == false) {
						f.getSeatMap().getSeat(i, (char) (j + 65)).setReserved(true);
						return f.getSeatMap().getSeat(i, (char) (j + 65));
					}
				}
			}
			return null;
		}
	}
}
