/**
 * This enum type is used to give the seat types would be used by other classes
 * 
 * @author TAO LI
 *
 */
public enum SEATTYPE {
	AISLE, MIDDLE, WINDOW;
}
