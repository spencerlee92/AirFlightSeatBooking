/**
 * This class is an abstract class which contain an abstract method
 * initialiseSeatMap which is used by subclass to define their own seat map.
 * Because different air plane types have different types of seat map. Also it
 * contain a two-dimension array to store seat which make the seat map more 2D
 * and some instance variables to store the row, column and the number of first
 * class row in the map.
 * 
 * @author TAO LI
 *
 */
public abstract class SeatMap {
	abstract void initialiseSeatMap();

	protected Seat[][] seat;
	private int row;
	private int column;
	private int rowOfFirstClass;

	public SeatMap(int r, int c, int row, int column, int rowOfFirstClass) {
		this.setSeat(r, c);
		this.setRow(row);
		this.setColumn(column);
		this.setRowOfFirstClass(rowOfFirstClass);
	}

	public SeatMap() {
		this.setSeat(0, 0);
		this.setRow(0);
		this.setColumn(0);
		this.setRowOfFirstClass(0);
	}

	/**
	 * This method return the last row of the map
	 * 
	 * @return last row number of the map
	 */

	public int getLastRow() {

		return this.getRow();
	}

	/**
	 * This method return the last column of the map
	 * 
	 * @return last column char of the map
	 */

	public char getLastColumn() {
		return (char) (this.getColumn() + 64);
	}

	/**
	 * This method is used to get a seat in the seat map and convert the column
	 * input parameter into integer number which can be used by the two
	 * dimension array.
	 * 
	 * @param the
	 *            number of row
	 * @param the
	 *            number of column which use char to represent
	 * @return a 2D seat
	 */

	protected Seat getSeat(int row, char column) {
		int col;
		row--;
		col = (int) column - 65;
		return seat[row][col];
	}

	public Seat[][] getSeat() {
		return seat;
	}

	/**
	 * These two method getLeft and getRight take a seat input parameter and
	 * they would according to the array row indice and the ascii value to get
	 * the right or left side seat of the input parameter seat
	 * 
	 * @param a
	 *            seat
	 * @return a seat on the right or left side of the input seat
	 */

	public Seat getLeft(Seat st) {

		int a = st.getSeatPosition().getRow() - 1;
		int b = st.getSeatPosition().getColumn() - 66;// The value of left seat
														// in the array
		if (b < 0)
			return null;
		else
			return seat[a][b];
	}

	public Seat getRight(Seat st) {

		int a = st.getSeatPosition().getRow() - 1;
		int b = st.getSeatPosition().getColumn() - 64;// The value of right seat
														// in the array
		if (b > this.getColumn() - 1)
			return null;
		else
			return seat[a][b];
	}

	/**
	 * This method is used to find a seat with the requested seat type in the
	 * two-dimension array. It would only check the row of first class, its
	 * matching seat type, and it has already reserved or not
	 * 
	 * @param requested
	 *            SEATTYPE
	 * @return find a seat with the matching seat type in the first class if
	 *         there is no seat available then return null
	 */

	public Seat queryAvailableFirstSeat(SEATTYPE sT) {
		for (int i = 0; i < this.getRowOfFirstClass(); i++) {
			for (int j = 0; j < seat[i].length; j++) {
				if (seat[i][j].getSeatType() == sT && seat[i][j].isReserved() == false) {
					return seat[i][j];
				}
			}
		}
		return null;
	}

	/**
	 * This method is used to find a seat with the requested seat type in the
	 * two-dimension array. It would only check the row of economy class, its
	 * matching seat type, and it has already reserved or not
	 * 
	 * @param requested
	 *            SEATTYPE
	 * @return find a seat with the matching seat type in the economy class if
	 *         there is no seat available then return null
	 */

	public Seat queryAvailableEconomySeat(SEATTYPE sT) {
		for (int i = this.getRowOfFirstClass(); i < seat.length; i++) {
			for (int j = 0; j < seat[i].length; j++) {
				if (seat[i][j].getSeatType() == sT && seat[i][j].isReserved() == false) {
					return seat[i][j];
				}
			}
		}
		return null;
	}

	/**
	 * This method is used to create a seat map. It would create the column
	 * first
	 *
	 * @return a string representation of the seat
	 */
	public String toString() {
		String s = "";
		for (int a = 0; a < this.getColumn(); a++) {
			s += "     " + (char) (65 + a);
		}
		s += "\n";
		for (int i = 0; i < this.getRow(); i++) {
			if ((i + 1) < 10) {
				s += " " + (i + 1);
			} else {
				s += (i + 1);
			}
			for (int j = 0; j < this.getColumn(); j++) {

				s += seat[i][j];
			}
			s += "\n";

		}

		return s;
	}

	protected void setSeat(int row, int column) {
		this.seat = new Seat[row][column];
	}

	public int getRow() {
		return row;
	}

	protected void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	protected void setColumn(int column) {
		this.column = column;
	}

	public int getRowOfFirstClass() {
		return rowOfFirstClass;
	}

	protected void setRowOfFirstClass(int rowOfFirstClass) {
		this.rowOfFirstClass = rowOfFirstClass;
	}

}
