/**
 * This class is used for testing
 * 
 * @author TAO LI
 *
 */
public class Test {

	public static void main(String args[]) {
		AirlineReservationApplication a = new AirlineReservationApplication();

		a.welcome();
		a.goodbye();

	}
}
